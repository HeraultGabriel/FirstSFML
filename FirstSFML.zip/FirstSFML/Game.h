#pragma once

#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>

#include "GameContent.h"
#include "GameDataLoader.h"
#include "Player.h"


using namespace sf;
using SFMLString = String;

class Game
{
	GameDataLoader* loader = new GameDataLoader("Graphics",
		{
			"luigi.png",
			"wall.png",
			"ground.png",
			"coin.png",
			"movementsheet.png",
			"HolySheet.png"
		});

	GameContent* currentContent = new GameContent();
	RenderWindow* currentWindow = nullptr;
	Player* player = nullptr;
	Coin* coin = new Coin();

	sf::Clock timer;
	float fps;
	static float deltaTime;

public:
	static const float DeltaTime() { return deltaTime; }

	Game(int _width, int _height, std::string _name)
	{
		currentWindow = new RenderWindow(VideoMode(Vector2u(_width, _height)), _name);
	}
	Game(const Game& _copy)
	{
		this->currentWindow = _copy.currentWindow;
	}
	~Game()
	{
		delete player;
		delete currentContent;
		delete currentWindow;
		delete loader;
		delete coin;
	}

public:
	void StartGame();

private:
	void OnStart();
	void OnFrameUpdate();
};
