#include "GameDataLoader.h"

std::vector <sf::Texture> GameDataLoader::allTextures = {};

void GameDataLoader::LoadData()
{
	for (int i = 0; i < filesName.size(); i++)
	{
		allTextures.push_back(sf::Texture(folderName + "\\" + filesName[i]));
	}
}

//void GameDataLoader::LoadData()
//{
	//sf::Texture _tmp;
	//for (int i = 0; i < filesName.size(); i++)
	//{
		//if (_tmp.loadFromFile(folderName + "\\" + filesName[i]))
		//{ 
			//allTextures.push_back(sf::Texture(folderName + "\\" + filesName[i]));
		//}
	//}
//}