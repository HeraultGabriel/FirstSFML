#include "MapElement.h"

void MapElement::Draw(sf::RenderWindow& _window)
{
	_window.draw(shape);
}
