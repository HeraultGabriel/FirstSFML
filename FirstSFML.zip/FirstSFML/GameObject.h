#pragma once

#include <SFML/Graphics.hpp>

class GameObject
{
public : 
	GameObject() {}
	virtual ~GameObject() {}

public : 
	virtual void Draw(sf::RenderWindow& _window) {}
};

