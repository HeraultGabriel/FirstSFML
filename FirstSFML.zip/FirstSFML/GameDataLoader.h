#pragma once

#include <string>
#include <vector>
#include <SFML/Graphics.hpp>

class GameDataLoader
{
	std::string folderName;
	std::vector<std::string> filesName = {};

public:
	static std::vector <sf::Texture> allTextures;

public:
	sf::Texture playerTexture;
	GameDataLoader() {}
	GameDataLoader(const std::string& _folder, std::vector<std::string> _files)
	{
		folderName = _folder;
		filesName = _files;
	}

public :
	void LoadData();
};

