#include "GPE.h"
#include "GameDataLoader.h"

void GPE::Draw(sf::RenderWindow& _window)
{
	_window.draw(shapeGPE);
}
